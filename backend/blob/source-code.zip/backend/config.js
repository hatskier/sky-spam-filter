module.exports = {
  db: 'mongodb+srv://alex:Admin123@sky-spam-filter-cluster-oo4gh.mongodb.net/test?retryWrites=true&w=majority',
  port: 8080,
};
